import 'package:captain_app/core/constants.dart';
import 'package:captain_app/models/auth_model.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

// ignore: must_be_immutable
class AppBarWidget extends StatelessWidget {
  const AppBarWidget({
    super.key,
    required this.isOnline,
    required this.userName,
    required this.role,
  });

  final bool isOnline;
  final String userName;
  final DeliveryType role;
  @override
  Widget build(BuildContext context) {
    final isReserve = role == DeliveryType.reserve;
    return Row(
      children: [
        Flexible(
          child: Row(
            children: [
              Flexible(
                child: Text(
                  userName,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 18.sp,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              SizedBox(width: 6.w),
              Icon(Icons.circle, color: Colors.green, size: 10.r),
              SizedBox(width: 6.w),

              Text(
                isReserve ? AppConstants.roleBackup : AppConstants.rolePrimary,
                style: TextStyle(fontSize: 16.sp, fontWeight: FontWeight.bold),
              ),
            ],
          ),
        ),
        SizedBox(width: 8.w),
        Image.asset(
          "assets/images/DF_logo_for_dash.png",
          height: 70.h,
          width: 140.w,
          fit: BoxFit.contain,
        ),
      ],
    );
  }
}
