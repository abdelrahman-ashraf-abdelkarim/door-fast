// lib/services/web_socket_service.dart
import 'dart:async';
import 'dart:convert';
import 'package:captain_app/core/constants.dart';
import 'package:pusher_channels_flutter/pusher_channels_flutter.dart';

class WebSocketService {
  WebSocketService._internal();
  static final WebSocketService _instance = WebSocketService._internal();
  factory WebSocketService() => _instance;

  static final PusherChannelsFlutter _pusher =
      PusherChannelsFlutter.getInstance();

  bool _initialized = false;
  bool _isConnected = false;

  int _retryCount = 0;
  Timer? _retryTimer;

  Duration get _retryDelay {
    final seconds = (5 * (1 << _retryCount)).clamp(5, 60);
    return Duration(seconds: seconds);
  }

  final StreamController<Map<String, dynamic>> _controller =
      StreamController<Map<String, dynamic>>.broadcast();

  Stream<Map<String, dynamic>> get stream => _controller.stream;

  String? _token;
  String? _captainId;

  // ─── Public API ───────────────────────────────────────────────────────────

  Future<void> connect(String token, String captainId) async {
    print('[WS] connect() called | _initialized=$_initialized | _isConnected=$_isConnected');
    if (_initialized) {
      print('[WS] connect() skipped — already initialized');
      return;
    }
    _initialized = true;
    _isConnected = false;
    _token = token;
    _captainId = captainId;
    _retryCount = 0;
    print('[WS] connect() starting _init() | captainId=$captainId');
    await _init();
  }

  Future<void> disconnect() async {
    print('[WS] disconnect() called');
    _initialized = false;
    _isConnected = false;
    _retryTimer?.cancel();
    _retryTimer = null;
    _retryCount = 0;
    final captainId = _captainId;
    _token = null;
    _captainId = null;
    try {
      await _pusher.unsubscribe(channelName: 'orders');
      if (captainId != null) {
        await _pusher.unsubscribe(channelName: 'delivery.$captainId');
      }
      await _pusher.disconnect();
      print('[WS] disconnect() done');
    } catch (e) {
      print('[WS] disconnect() error: $e');
    }
  }

  Future<void> reconnect() async {
    print('[WS] reconnect() called | _token=$_token | _isConnected=$_isConnected | _initialized=$_initialized');
    if (_token == null || _captainId == null) {
      print('[WS] reconnect() aborted — no token or captainId');
      return;
    }
    if (_isConnected) {
      print('[WS] reconnect() skipped — already connected');
      return;
    }
    print('[WS] reconnect() doing full reset and re-init');
    _initialized = false;
    _retryTimer?.cancel();
    _retryTimer = null;
    _retryCount = 0;
    _initialized = true;
    await _init();
  }

  // ─── Internal ─────────────────────────────────────────────────────────────

  Future<void> _init() async {
    print('[WS] _init() started');
    try {
      await _pusher.init(
        apiKey: AppConstants.apiKey,
        cluster: AppConstants.cluster,

        onEvent: (dynamic event) {
          if (event is PusherEvent) {
            print('[WS] onEvent (global): eventName=${event.eventName} | channel=${event.channelName}');
            _handleEvent(event);
          }
        },

        onConnectionStateChange: (currentState, previousState) {
          print('[WS] connectionState: $previousState → $currentState');
          if (currentState == 'CONNECTED') {
            _isConnected = true;
            _retryCount = 0;
            _retryTimer?.cancel();
            _retryTimer = null;
            print('[WS] CONNECTED ✅');
          }
          if (currentState == 'DISCONNECTED') {
            _isConnected = false;
            print('[WS] DISCONNECTED ❌ | _token=$_token | retryCount=$_retryCount');
            if (_token != null) {
              _scheduleRetryConnect();
            }
          }
        },

        onError: (message, code, error) {
          print('[WS] onError: message=$message | code=$code | error=$error');
          _isConnected = false;
          _initialized = false;
          if (_token != null) {
            _scheduleRetryInit();
          }
        },
      );

      print('[WS] subscribing to channel: orders');
      await _pusher.subscribe(
        channelName: 'orders',
        onEvent: (dynamic event) {
          if (event is PusherEvent) {
            print('[WS] onEvent (orders): eventName=${event.eventName} | data=${event.data}');
            _handleEvent(event);
          }
        },
      );

      if (_captainId != null) {
        print('[WS] subscribing to channel: delivery.$_captainId');
        await _pusher.subscribe(
          channelName: 'delivery.$_captainId',
          onEvent: (dynamic event) {
            if (event is PusherEvent) {
              print('[WS] onEvent (delivery.$_captainId): eventName=${event.eventName} | data=${event.data}');
              _handleEvent(event);
            }
          },
        );
      }

      print('[WS] calling _pusher.connect()');
      await _pusher.connect();
    } catch (e) {
      print('[WS] _init() exception: $e');
      _isConnected = false;
      _initialized = false;
      if (_token != null) {
        _scheduleRetryInit();
      }
    }
  }

  void _scheduleRetryConnect() {
    final delay = _retryDelay;
    print('[WS] _scheduleRetryConnect() in ${delay.inSeconds}s | retryCount=$_retryCount');
    _retryTimer?.cancel();
    _retryTimer = Timer(delay, () {
      _retryCount++;
      print('[WS] retrying connect()... retryCount=$_retryCount');
      if (_token != null) _pusher.connect();
    });
  }

  void _scheduleRetryInit() {
    final delay = _retryDelay;
    print('[WS] _scheduleRetryInit() in ${delay.inSeconds}s | retryCount=$_retryCount');
    _retryTimer?.cancel();
    _retryTimer = Timer(delay, () {
      _retryCount++;
      print('[WS] retrying _init()... retryCount=$_retryCount');
      if (_token != null) {
        _initialized = true;
        _init();
      }
    });
  }

  // ─────────────────────────────────────────────────────────────────────────

  void _handleEvent(PusherEvent event) {
    print('[WS] _handleEvent: eventName=${event.eventName} | channel=${event.channelName}');
    try {
      final raw = _decode(event.data);

      switch (event.eventName) {
        case 'App\\Events\\NewOrderEvent':
          final message = raw['order'] ?? raw;
          final orderId =
              message['id']?.toString() ?? message['order_id']?.toString();
          print('[WS] → new_order | orderId=$orderId');
          if (orderId != null) {
            _addEvent({'event': 'new_order', 'order_id': orderId});
          }
          break;

        case 'App\\Events\\OrderStatusUpdated':
          final message = raw['message'] ?? raw;
          final orderId = (message['order_id'] ?? message['id'])?.toString();
          final status = message['status']?.toString();
          final deliveryId = message['delivery_id']?.toString();
          print('[WS] → order_updated | orderId=$orderId | status=$status | deliveryId=$deliveryId');
          if (orderId != null) {
            _addEvent({
              'event': 'order_updated',
              'order_id': orderId,
              'status': status,
              'delivery_id': deliveryId,
            });
          }
          break;

        case 'reserve_new_order':
          final message = raw['order'] ?? raw;
          final orderId =
              message['id']?.toString() ?? message['order_id']?.toString();
          print('[WS] → reserve_new_order | orderId=$orderId');
          if (orderId != null) {
            _addEvent({'event': 'reserve_new_order', 'order_id': orderId});
          }
          break;

        case 'order.cancelled':
          final orderId = raw['order_id']?.toString();
          print('[WS] → order_cancelled | orderId=$orderId');
          if (orderId != null) {
            _addEvent({'event': 'order_cancelled', 'order_id': orderId});
          }
          break;

        case 'shift.updated':
          final status = raw['status']?.toString();
          print('[WS] → shift.updated | status=$status');
          if (status == 'started') {
            _addEvent({'event': 'shift_activated'});
          } else if (status == 'ended') {
            _addEvent({'event': 'shift_deactivated'});
          }
          break;

        case 'account.deactivated':
          print('[WS] → account_deactivated');
          _addEvent({'event': 'account_deactivated'});
          break;

        case 'wallet.updated':
          final balance = raw['balance'];
          final amount = raw['amount'];
          final type = raw['type'];
          final dir = raw['direction'];
          print('[WS] → wallet_updated | balance=$balance | amount=$amount | type=$type | dir=$dir');
          _addEvent({
            'event': 'wallet_updated',
            'balance': balance?.toString(),
            'amount': amount?.toString(),
            'type': type?.toString(),
            'direction': dir?.toString(),
          });
          break;

        default:
          // ✅ أي event مش متعرف عليه — مهم جداً على السيرفر الحقيقي
          print('[WS] ⚠️ UNKNOWN EVENT: ${event.eventName} | channel=${event.channelName} | data=${event.data}');
          break;
      }
    } catch (e) {
      print('[WS] _handleEvent() exception: $e | eventName=${event.eventName}');
    }
  }

  void _addEvent(Map<String, dynamic> event) {
    if (_controller.isClosed) {
      print('[WS] _addEvent() skipped — controller is closed | event=$event');
      return;
    }
    print('[WS] _addEvent() → $event');
    _controller.add(event);
  }

  Map<String, dynamic> _decode(dynamic data) {
    if (data == null) return {};
    if (data is Map<String, dynamic>) return data;
    if (data is String) {
      try {
        return jsonDecode(data) as Map<String, dynamic>;
      } catch (e) {
        print('[WS] _decode() failed: $e | raw=$data');
        return {};
      }
    }
    return {};
  }
}